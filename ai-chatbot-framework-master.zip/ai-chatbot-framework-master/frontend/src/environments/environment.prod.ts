export const environment = {
  production: true,
  ikyBackend: "/gateway/"
};
