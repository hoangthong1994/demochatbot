import pytest


def f():
    return 4


def test_function():
    assert f() == 4
